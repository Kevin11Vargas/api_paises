import 'package:api_paises_app/providers/database_helper.dart';
import 'package:flutter/material.dart';
import 'package:api_paises_app/models/country_model.dart';

class FavoritosScreen extends StatefulWidget {
  @override
  _FavoritosScreenState createState() => _FavoritosScreenState();
}

class _FavoritosScreenState extends State<FavoritosScreen> {
  late List<Country> favoritos = []; // Inicializar con una lista vacía

  @override
  void initState() {
    super.initState();
    // Llama a la función para cargar la lista de favoritos
    cargarFavoritos();
  }

  void cargarFavoritos() async {
    // Utiliza el DatabaseHelper para obtener la lista de favoritos
    final List<Country> favoritosList = await DatabaseHelper.instance.getFavorites();

    setState(() {
      favoritos = favoritosList;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Países Favoritos'),
      ),
      body: favoritos.isEmpty
          ? Center(child: Text('No hay países favoritos.'))
          : ListView.builder(
              itemCount: favoritos.length,
              itemBuilder: (context, index) {
                final country = favoritos[index];
                return Card(
                  child: ListTile(
                    leading: Image.network(country.flagUrl, height: 48, width: 48),
                    title: Text(country.name),
                    subtitle: Text(country.region),
                  ),
                );
              },
            ),
    );
  }
}