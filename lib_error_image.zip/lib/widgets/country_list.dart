import 'package:api_paises_app/details/country_details.dart';
import 'package:api_paises_app/models/country_model.dart';
import 'package:flutter/material.dart';

class CountryList extends StatelessWidget {
  final List<Country> countries;

  CountryList({required this.countries});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: countries.length,
      itemBuilder: (context, index) {
        final country = countries[index];
        return GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => CountryDetails(country: country),
              ),
            );
          },
          child: Card(
            color: Colors.white.withOpacity(0.11), // Ajusta el valor de opacidad según tus preferencias
            child: ListTile(
              leading: Image.network(country.flagUrl, height: 48, width: 48),
              title: Text(country.name),
              subtitle: Text(country.region),
            ),
          ),
        );
      },
    );
  }
}