import 'package:api_paises_app/models/country_model.dart';
import 'package:flutter/material.dart';

class CountryDetails extends StatelessWidget {
  final Country country;

  CountryDetails({required this.country});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(country.name),
        
      ),
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/earth_background.jpg'),  // Ajusta la ruta según la ubicación de tu imagen
            fit: BoxFit.fill,
          ),
        ),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.only(right: 10.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Nombre: ${country.name}',
                  style: TextStyle(color: Color.fromARGB(255, 0, 0, 0), fontSize: 20),
                ),
                Text(
                  'Capital: ${country.capital}',
                  style: TextStyle(color: Color.fromARGB(255, 0, 0, 0), fontSize: 20),
                ),
                Text(
                  'Region: ${country.region}',
                  style: TextStyle(color: Color.fromARGB(255, 0, 0, 0), fontSize: 20),
                ),
                Image.network(country.flagUrl, height: 150, width: 300), // Ajusta el tamaño de la bandera aquí
              ],
            ),
          ),
        ),
      ),
    );
  }
}