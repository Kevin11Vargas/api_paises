import 'package:api_paises_app/pages/check_auth_screen.dart';
import 'package:api_paises_app/pages/login_screen.dart';
import 'package:api_paises_app/pages/register_screen.dart';
import 'package:api_paises_app/screens/favorite_screen.dart';
import 'package:api_paises_app/screens/home_screen.dart';
import 'package:api_paises_app/services/auth_services.dart';
import 'package:api_paises_app/services/notifications_services.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:api_paises_app/providers/country_provider.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => CountryProvider()),
        ChangeNotifierProvider(create: (_) => AuthService()),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'API Países',
        initialRoute: 'checking',
        routes: {
          'checking': (_) => CheckAuthScreen(),
          'login': (_) => LoginScreen(),
          'register': (_) => RegisterScreen(),
          'home': (_) => HomeScreen(authService: AuthService(),),
          'favorites': (_) => FavoritesScreen(),
        },
        scaffoldMessengerKey: NotificationsService.messengerKey,
        theme: ThemeData.light().copyWith(
          scaffoldBackgroundColor: Color.fromARGB(255, 75, 75, 75),
          appBarTheme: const AppBarTheme(
            elevation: 0,
            color: Color.fromARGB(255, 75, 75, 75),
          ),
          floatingActionButtonTheme: const FloatingActionButtonThemeData(
            backgroundColor: Colors.redAccent,
            elevation: 0,
          ),
        ),
      ),
    );
  }
}
