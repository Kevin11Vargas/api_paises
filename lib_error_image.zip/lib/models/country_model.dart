class Country {
  final String id;
  final String name;
  final String capital;
  final String region;
  final String flagUrl;

  Country({
    required this.id,
    required this.name,
    required this.capital,
    required this.region,
    required this.flagUrl,
  });

  factory Country.fromJson(Map<String, dynamic> json) {
  try {
    final name = (json['name'] as Map<String, dynamic>?)?.cast<String, dynamic>() ?? {};
    final commonName = name['common'] ?? '';
    final officialName = name['official'] ?? '';

    return Country(
  id: json['cca3'] ?? '',
  name: commonName,
  capital: (json['capital'] as List<dynamic>?)?.isNotEmpty == true
      ? json['capital'][0]
      : '',
  region: json['region'] ?? '',
  flagUrl: (json['flags'] as Map<String, dynamic>?)?['svg'] ?? '', // Reemplaza 'flags' con el campo real del JSON
);
  } catch (e) {
    print('Error parsing country: $e');
    throw Exception('Error parsing country');
  }
}
}