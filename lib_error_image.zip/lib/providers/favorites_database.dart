import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class FavoritesDatabase {
  late Database _database;

  Future<void> initDatabase() async {
    _database = await openDatabase(
      join(await getDatabasesPath(), 'favorites_database.db'),
      onCreate: (db, version) {
        return db.execute(
          'CREATE TABLE favorites(id TEXT PRIMARY KEY)',
        );
      },
      version: 1,
    );
  }

  Future<void> addToFavorites(String countryId) async {
    await _database.insert(
      'favorites',
      {'id': countryId},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> removeFromFavorites(String countryId) async {
    await _database.delete(
      'favorites',
      where: 'id = ?',
      whereArgs: [countryId],
    );
  }

  Future<List<String>> getFavoriteCountryIds() async {
    final List<Map<String, dynamic>> maps = await _database.query('favorites');

    return List.generate(maps.length, (i) {
      return maps[i]['id'] as String;
    });
  }

  Future<void> saveFavoriteCountryIds(List<String> favoriteIds) async {
    // Implementa el código para guardar la lista de favoritos en la base de datos
    await _database.transaction((txn) async {
      for (String countryId in favoriteIds) {
        await txn.insert(
          'favorites',
          {'id': countryId},
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      }
    });
  }
}

