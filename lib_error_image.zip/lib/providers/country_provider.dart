import 'package:api_paises_app/models/country_model.dart';
import 'package:api_paises_app/providers/favorites_database.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

class FavoritesManager {
  final FavoritesDatabase _favoritesDatabase = FavoritesDatabase();
  List<Country> _favorites = [];

  List<Country> get favorites => _favorites;

  Future<void> initFavorites() async {
    await _loadFavorites();
  }

  Future<void> _loadFavorites() async {
    final List<String> favoriteIds = await _favoritesDatabase.getFavoriteCountryIds();
    _favorites = await CountryProvider().getCountriesByIds(favoriteIds);
  }

  Future<void> _saveFavorites() async {
    final List<String> favoriteIds = _favorites.map((country) => country.id).toList();
    await _favoritesDatabase.saveFavoriteCountryIds(favoriteIds);
  }

  Future<void> addToFavorites(Country country) async {
    await _favoritesDatabase.addToFavorites(country.id);
    _favorites.add(country);
    await _saveFavorites();
  }

  Future<void> removeFromFavorites(Country country) async {
    await _favoritesDatabase.removeFromFavorites(country.id);
    _favorites.remove(country);
    await _saveFavorites();
  }
}

class CountryProvider with ChangeNotifier {
  final Dio _dio = Dio();
  List<Country> _favoriteCountries = [];

  List<Country> get favoriteCountries => _favoriteCountries;

  Future<List<Country>> getCountries() async {
  try {
    final response = await _dio.get('https://restcountries.com/v3.1/all');
    if (response.statusCode == 200) {
      final List<Country> countries = (response.data as List? ?? [])
          .map((json) => Country.fromJson(json['properties'] ?? {}))
          .toList();
      return countries;
    } else {
      print('Failed to load countries: ${response.statusCode}');
      print('Response body: ${response.data}');
      throw Exception('Failed to load countries: ${response.statusCode}');
    }
  } catch (e) {
    if (e is DioError) {
      print('DioError: ${e.message}');
    }
    print('Failed to load countries: $e');
    throw Exception('Failed to load countries');
  }
}

  Future<List<Country>> getCountriesByIds(List<String> countryIds) async {
    final List<Country> allCountries = await getCountries();
    return allCountries.where((country) => countryIds.contains(country.id)).toList();
  }

  Future<void> addToFavorites(Country country) async {
    if (!_favoriteCountries.contains(country)) {
      _favoriteCountries.add(country);
      notifyListeners();
    }
  }

  Future<void> removeFromFavorites(Country country) async {
    _favoriteCountries.remove(country);
    notifyListeners();
  }
}
 
// class CountryProvider with ChangeNotifier {
//   final Dio _dio = Dio();
//   List<Country> _favoriteCountries = [];

//   List<Country> get favoriteCountries => _favoriteCountries;

//   FavoritesDatabase _favoritesDatabase = FavoritesDatabase();

//   Future<List<Country>> getCountries() async {
//     try {
//       final response = await _dio.get('https://restcountries.com/v3.1/all');
//       if (response.statusCode == 200) {
//         return (response.data as List? ?? [])
//             .map((json) => _jsonToCountry(json))
//             .toList();
//       } else {
//         print('Failed to load countries: ${response.statusCode}');
//         print('Response body: ${response.data}');
//         throw Exception('Failed to load countries: ${response.statusCode}');
//       }
//     } catch (e) {
//       if (e is DioError) {
//         print('DioError: ${e.message}');
//       }
//       print('Failed to load countries: $e');
//       throw Exception('Failed to load countries');
//     }
//   }

//   Country _jsonToCountry(Map<String, dynamic> json) {
//     return Country(
//       id: json['cca3'] ?? '',
//       name: json['name']['common'] ?? '',
//       capital: json['capital'] ?? '',
//       region: json['region'] ?? '',
//       flagUrl: json['flags']['png'] ?? '',
//     );
//   }

//   Future<List<Country>> getCountriesByIds(List<String> countryIds) async {
//     final List<Country> allCountries = await getCountries();
//     return allCountries.where((country) => countryIds.contains(country.id)).toList();
//   }

//   Future<void> addToFavorites(Country country) async {
//     await _favoritesDatabase.addToFavorites(country.id);
//     _favoriteCountries.add(country);
//     notifyListeners();
//   }

//   Future<void> removeFromFavorites(Country country) async {
//     await _favoritesDatabase.removeFromFavorites(country.id);
//     _favoriteCountries.remove(country);
//     notifyListeners();
//   }
// }