import 'package:api_paises_app/models/country_model.dart';
import 'package:api_paises_app/providers/country_provider.dart';
import 'package:api_paises_app/widgets/country_list.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class FavoritesScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final countryProvider = Provider.of<CountryProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('Países Favoritos'),
      ),
      body: ListView.builder(
        itemCount: countryProvider.favoriteCountries.length,
        itemBuilder: (context, index) {
          final country = countryProvider.favoriteCountries[index];
          return ListTile(
            title: Text(country.name),
            // Agrega más detalles o personalización según tus necesidades
          );
        },
      ),
    );
  }
}